/** 
  * ControleDC Library V1.1
  *
  * @author F�bio Garcez Bettio
  * @see contato@bettech.com.br
  *
 -------------------------------------------------------
 Data: 30/10/2013
 Autor: Fabio Bettio
 --------------------------------------------------------*/

 
#ifndef ControleDC_h
#define ControleDC_h

#include "Arduino.h"

void inicializaDriveMotor(int M1A, int M1B, int M2A, int M2B);

//APIs
void horarioM1();
void horarioM2();
void anti_horarioM1();
void anti_horarioM2();
void pararM1();
void pararM2();

//baixo nivel

void horario(int Pin_motA,int Pin_motB);
void anti_horario(int Pin_motA,int Pin_motB);
void parar(int Pin_motA,int Pin_motB);


 
class ControleDC {  
  public:
    ControleDC(int);
    void setPin(int);
    void setState(bool);
    void turnOn();
    void turnOff();
    int  getPin();
    bool getState();
    bool getStatus();
    bool isOn();
    bool isOff();
  private:
    int _pin;
    bool _state;
};
 
#endif