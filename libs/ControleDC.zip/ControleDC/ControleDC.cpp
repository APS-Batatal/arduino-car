/** 
  * ControleDC Library v1.1
  * @author Fabio Garcez Bettio
  * @see contato@bettech.com.br
  */
 
#include "Arduino.h"
#include "ControleDC.h"


int pinoMotor1A;
int pinoMotor1B;
int pinoMotor2A;
int pinoMotor2B;

void inicializaDriveMotor(int M1A, int M1B, int M2A, int M2B)
{
   pinoMotor1A = M1A;
   pinoMotor1B = M1B;
   pinoMotor2A = M2A;
   pinoMotor2B = M2B;
	
   pinMode(pinoMotor1A , OUTPUT);
   pinMode(pinoMotor1B, OUTPUT);
   pinMode(pinoMotor2A, OUTPUT);
   pinMode(pinoMotor2B, OUTPUT);
}
//------------------------------------------------------
// ===================== ==========================
/*-------------------------------------------------------
 APIs 
 Descricao: 
 Parametros: nada
 Retornos: 
 Indiretos: nada
 Data: 30/10/2013 
 Autor: Fabio Bettio
 --------------------------------------------------------*/


// ================================== Hoario ==================================
void horarioM1()
{
   digitalWrite(pinoMotor1A, LOW);
   digitalWrite(pinoMotor1B, HIGH);
}
void horarioM2()
{
   digitalWrite(pinoMotor2A, LOW);
   digitalWrite(pinoMotor2B, HIGH);
}


// ================================== Anti-Hoario ============================
void anti_horarioM1()
{
  digitalWrite(pinoMotor1A, HIGH);
  digitalWrite(pinoMotor1B, LOW);
}
void anti_horarioM2()
{
  digitalWrite(pinoMotor2A, HIGH);
  digitalWrite(pinoMotor2B, LOW);
}


// ================================== Parar ==================================
void pararM1()
{
 digitalWrite(pinoMotor1A, LOW);   
 digitalWrite(pinoMotor1B, LOW); 
}
void pararM2()
{
 digitalWrite(pinoMotor2A, LOW);   
 digitalWrite(pinoMotor2B, LOW); 
}

//============================================================================


/*-------------------------------------------------------
 FUNCOES DE BAIXO NIVEL === ACESSO AO HARDWARE
 Descricao: 
 Parametros: nada
 Retornos: 
 Indiretos: nada
 Data: 30/10/2013 
 Autor: Fabio Bettio
 --------------------------------------------------------*/
void horario(int Pin_motA,int Pin_motB)
{
   digitalWrite(Pin_motA, LOW);
   digitalWrite(Pin_motB, HIGH);
}
void anti_horario(int Pin_motA,int Pin_motB)
{
  digitalWrite(Pin_motA, HIGH);
  digitalWrite(Pin_motB, LOW);
}
void parar(int Pin_motA,int Pin_motB)
{
 digitalWrite(Pin_motA, LOW);   
 digitalWrite(Pin_motB, LOW); 
}



// TABELA DE CONTROLE DO MOTOR 1/2
// P0 P1   SENTIDO          P2 P3  SENTIDO
// 0  0    PARADO           0  0   PARADO
// 0  1    FRENTE           0  1   FRENTE
// 1  0    RE               1  0   RE
// 1  1    PARADO           1  1   PARADO